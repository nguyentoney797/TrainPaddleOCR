
./build/ocr_system ./tools/config.txt ../../doc/imgs/12.jpg

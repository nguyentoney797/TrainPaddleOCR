'''
PADDLE: Proximal Algorithms for Dual Dictionary LEarning
'''

import common, dual, tight, data, prox

# major number for main changes
# minor number for new features
# release number for bug fixes and minor updates
__version__ = '1.0.2'

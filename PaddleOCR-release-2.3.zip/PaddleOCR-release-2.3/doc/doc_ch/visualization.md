# 效果展示

<a name="超轻量PP-OCRv2效果展示"></a>
## 超轻量PP-OCRv2效果展示
   <img src="../imgs_results/PP-OCRv2/PP-OCRv2-pic001.jpg" width="800">
   <img src="../imgs_results/PP-OCRv2/PP-OCRv2-pic002.jpg" width="800">
   <img src="../imgs_results/PP-OCRv2/PP-OCRv2-pic003.jpg" width="800">

<a name="超轻量ppocr_server_2.0效果展示"></a>
## 通用PP-OCR server 效果展示

<div align="center">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00006737.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00009282.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00015504.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00018069.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00056221.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00057937.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00077949.jpg" width="800">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/00207393.jpg" width="800">
</div>


<a name="英文识别模型效果展示"></a>
## 英文识别模型效果展示
<div align="center">
    <img src="../imgs_results/ch_ppocr_mobile_v2.0/img_12.jpg" width="800">
</div>


<a name="多语言识别模型效果展示"></a>
## 多语言识别模型效果展示
<div align="center">
    <img src="../imgs_results/french_0.jpg" width="800">
    <img src="../imgs_results/korean.jpg" width="800">
</div>
